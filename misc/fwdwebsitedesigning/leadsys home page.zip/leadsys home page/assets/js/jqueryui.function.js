$(function() {
    $( ".ui-tabs" ).tabs();
    $( ".ui-toggle" ).accordion({ active: false, autoHeight: false, collapsible: true, });
});